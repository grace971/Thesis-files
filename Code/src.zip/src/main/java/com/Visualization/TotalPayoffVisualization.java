package com.Visualization;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

public class TotalPayoffVisualization {

    public static void displayTotalPayoffChartFromCSV(String filePath) {
        SwingUtilities.invokeLater(() -> {
            // Read payoffs from CSV
            double[] totalPayoffs = calculateTotalPayoffsFromCSV(filePath);

            // Example: you should pass or load this array as appropriate for your experiment
            double[] lambdas = {0.2, 0.9, 0.1, 0.8}; // <-- Set your lambda values here

            // Create the dataset for the bar chart
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            for (int agentId = 0; agentId < totalPayoffs.length; agentId++) {
                String label = String.format("Agent%d (λ = %.1f)", agentId, lambdas[agentId]);
                dataset.addValue(totalPayoffs[agentId], "Total Payoff", label);
            }

            // Create the bar chart
            JFreeChart barChart = ChartFactory.createBarChart(
                    "Total Payoffs of Players", // Chart title
                    "Agents", // X-axis label
                    "Total Payoff", // Y-axis label
                    dataset // Dataset
            );

            // Set font for title
            barChart.getTitle().setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 28));

            // Set font for legend (if present)
            if (barChart.getLegend() != null) {
                barChart.getLegend().setItemFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 28));
            }

            // Customize the chart
            CategoryPlot plot = barChart.getCategoryPlot();
            BarRenderer renderer = (BarRenderer) plot.getRenderer();
            renderer.setBarPainter(new BarRenderer().getBarPainter()); // Use the default bar painter
            renderer.setSeriesPaint(0, new Color(80, 128, 190)); // Set bar color
            renderer.setMaximumBarWidth(0.1); // Bars fill the category width

            // Customize axes
            CategoryAxis domainAxis = plot.getDomainAxis();
            domainAxis.setCategoryMargin(0.01); // No space between bars
            domainAxis.setLowerMargin(0.01);    // No space before first bar
            domainAxis.setUpperMargin(0.01);    // No space after last bar
            domainAxis.setLabelFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 28)); // BOLD for axis title
            domainAxis.setTickLabelFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 28));

            NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
            rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
            rangeAxis.setLabelFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 28)); // BOLD for axis title
            rangeAxis.setTickLabelFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 28));

            // Display the chart in a new window
            JFrame frame = new JFrame("Total Payoffs Bar Chart");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setLayout(new BorderLayout());
            frame.add(new ChartPanel(barChart), BorderLayout.CENTER);
            frame.pack();
            frame.setVisible(true);
        });
    }

    private static double[] calculateTotalPayoffsFromCSV(String filePath) {
        double[] totalPayoffs = null;
        double[] lambdas = {0.1, 0.5, 0.8};

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isHeader = true;

            while ((line = br.readLine()) != null) {
                if (isHeader) {
                    isHeader = false; // Skip the header row
                    continue;
                }
                String[] values = line.split(",");

                if (totalPayoffs == null) {
                    totalPayoffs = new double[values.length - 1]; // Initialize based on the number of agents
                }

                for (int i = 1; i < values.length; i++) { // Skip the "Round" column
                    totalPayoffs[i - 1] += Double.parseDouble(values[i]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return totalPayoffs;
    }
}
