import matplotlib.pyplot as plt

# Set up the figure
fig, ax = plt.subplots(figsize=(12, 3))

# Learning speed values
values = [round(i * 0.1, 1) for i in range(11)]
y = [0] * len(values)

# Plot points
ax.scatter(values, y, color='black', zorder=3)
for v in values:
    ax.text(v, -0.1, str(v), ha='center', va='top', fontsize=10)

# Draw x-axis line
ax.hlines(0, -0.05, 1.05, color='black')

# Draw group brackets above for Group2–Group5
group_labels = ["Group2", "Group3", "Group4", "Group5"]
group_positions = [(0.2, 0.3), (0.4, 0.5), (0.6, 0.7), (0.8, 1.0)]

for i, (x1, x2) in enumerate(group_positions):
    x_mid = (x1 + x2) / 2
    ax.plot([x1, x2], [0.15, 0.15], color='red', lw=1.5)
    ax.plot([x1, x1], [0.15, 0.12], color='red', lw=1.5)
    ax.plot([x2, x2], [0.15, 0.12], color='red', lw=1.5)
    ax.text(x_mid, 0.17, group_labels[i], color='red', ha='center', fontsize=10)

# Draw Group1 bracket below for (0.1, 0.9)
x1, x2 = 0.1, 0.9
ax.plot([x1, x2], [-0.3, -0.3], color='red', lw=1.5)
ax.plot([x1, x1], [-0.3, -0.27], color='red', lw=1.5)
ax.plot([x2, x2], [-0.3, -0.27], color='red', lw=1.5)
ax.text((x1 + x2) / 2, -0.36, "Group1", color='red', ha='center', fontsize=11)

# Labels
ax.text(0.5, -0.48, "LS Range", color='blue', ha='center', fontsize=12)

# Formatting
ax.set_ylim(-0.5, 0.4)
ax.set_xlim(-0.05, 1.05)
ax.axis('off')
ax.set_title("Learning Speed Grouped Values", fontsize=14)

plt.tight_layout()
plt.show()
