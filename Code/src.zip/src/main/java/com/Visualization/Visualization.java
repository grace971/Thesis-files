package com.Visualization;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.text.NumberFormat;
import java.util.List;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Visualization {

    public static void displayCharts(List<int[]> choicesList, List<double[]> payoffsHistory) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Agent Choices and Payoffs");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            // Create and add the payoffs chart
            JFreeChart payoffsChart = createPayoffsChart(payoffsHistory);
            ChartPanel payoffsChartPanel = new ChartPanel(payoffsChart);

            // Create and add the choices chart
            JFreeChart choicesChart = createChoicesChart(choicesList);
            ChartPanel choicesChartPanel = new ChartPanel(choicesChart);

            // Add both charts to a single panel
            JPanel chartsPanel = new JPanel(new GridLayout(2, 1));
            chartsPanel.add(payoffsChartPanel);
            chartsPanel.add(choicesChartPanel);
            frame.add(chartsPanel, BorderLayout.CENTER);

            // Add checkboxes to toggle visibility for each player
            JPanel checkboxPanel = new JPanel(new FlowLayout());
            for (int playerId = 0; playerId < payoffsHistory.size(); playerId++) {
                JCheckBox checkbox = new JCheckBox("Player " + playerId, true);
                int finalPlayerId = playerId;
                checkbox.addActionListener(e -> {
                    boolean visible = checkbox.isSelected();
                    // Toggle visibility of payoffs renderer
                    payoffsChart.getXYPlot().getRenderer().setSeriesVisible(finalPlayerId, visible);
                    // Toggle visibility of choices renderer
                    choicesChart.getXYPlot().getRenderer().setSeriesVisible(finalPlayerId, visible);
                });
                checkboxPanel.add(checkbox);
            }

            // Add the checkbox panel to the frame
            frame.add(checkboxPanel, BorderLayout.NORTH);

            frame.pack();
            frame.setVisible(true);
        });
    }

    private static JFreeChart createPayoffsChart(List<double[]> payoffsHistory) {
        XYSeriesCollection dataset = new XYSeriesCollection();

        for (int playerId = 0; playerId < payoffsHistory.size(); playerId++) {
            XYSeries series = new XYSeries("Player " + playerId);
            double[] playerPayoffs = payoffsHistory.get(playerId);
            for (int round = 0; round < playerPayoffs.length; round++) {
                series.add(round, playerPayoffs[round]);
            }
            dataset.addSeries(series);
        }

        JFreeChart chart = ChartFactory.createXYLineChart(
                "Payoffs of Player Actions Over Rounds",
                "Rounds",
                "Payoffs",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        // Set font for title
        chart.getTitle().setFont(new Font("SansSerif", Font.BOLD, 20));
        // Set font for legend
        if (chart.getLegend() != null) {
            chart.getLegend().setItemFont(new Font("SansSerif", Font.PLAIN, 20));
        }

        XYPlot plot = chart.getXYPlot();
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

        for (int i = 0; i < dataset.getSeriesCount(); i++) {
            renderer.setSeriesLinesVisible(i, true);
            renderer.setSeriesShapesVisible(i, true);
        }

        Shape shape = new Ellipse2D.Double(-5, -5, 12, 12);
        for (int i = 0; i < dataset.getSeriesCount(); i++) {
            renderer.setSeriesShape(i, shape);
        }

        renderer.setDefaultToolTipGenerator(new StandardXYToolTipGenerator(
                StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT,
                NumberFormat.getInstance(),
                NumberFormat.getInstance()
        ));

        plot.setRenderer(renderer);

        // Set font for axis labels and tick labels
        NumberAxis domainAxis = (NumberAxis) plot.getDomainAxis();
        domainAxis.setTickUnit(new NumberTickUnit(3.0)); // Show every 2nd round label
        domainAxis.setLabelFont(new Font("SansSerif", Font.PLAIN, 20));
        domainAxis.setTickLabelFont(new Font("SansSerif", Font.PLAIN, 20));

        // Enable minor ticks and grid lines
        domainAxis.setMinorTickMarksVisible(true);
        domainAxis.setMinorTickCount(2); // 2 minor ticks between major ticks (adjust as needed)
        plot.setDomainMinorGridlinesVisible(true);
        plot.setDomainMinorGridlinePaint(java.awt.Color.WHITE);

        // Major grid lines (already visible, but you can set color if needed)
        plot.setDomainGridlinesVisible(true);
        plot.setDomainGridlinePaint(java.awt.Color.WHITE);

        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setTickUnit(new NumberTickUnit(1.0)); // Show every 2 values on y-axis
        rangeAxis.setLabelFont(new Font("SansSerif", Font.PLAIN, 20));
        rangeAxis.setTickLabelFont(new Font("SansSerif", Font.PLAIN, 20));
        rangeAxis.setRange(0.0, 4.5); // Set range to [0, 1]
        return chart;
    }

    private static JFreeChart createChoicesChart(List<int[]> choicesList) {
        XYSeriesCollection dataset = new XYSeriesCollection();

        for (int playerId = 0; playerId < choicesList.get(0).length; playerId++) {
            XYSeries series = new XYSeries("Player " + playerId);
            for (int round = 0; round < choicesList.size(); round++) {
                series.add(round, choicesList.get(round)[playerId]);
            }
            dataset.addSeries(series);
        }

        JFreeChart chart = ChartFactory.createScatterPlot(
                "Choices of Players Over Rounds",
                "Rounds",
                "Choices",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        // Set font for title
        chart.getTitle().setFont(new Font("SansSerif", Font.BOLD, 20));
        // Set font for legend
        if (chart.getLegend() != null) {
            chart.getLegend().setItemFont(new Font("SansSerif", Font.PLAIN, 20));
        }

        XYPlot plot = chart.getXYPlot();
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(false, true);
        renderer.setDefaultToolTipGenerator(new StandardXYToolTipGenerator(
                StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT,
                NumberFormat.getInstance(),
                NumberFormat.getInstance()
        ));
        plot.setRenderer(renderer);

        NumberAxis domainAxis = (NumberAxis) plot.getDomainAxis();
        domainAxis.setTickUnit(new NumberTickUnit(3.0));
        domainAxis.setLabelFont(new Font("SansSerif", Font.PLAIN, 20));
        domainAxis.setTickLabelFont(new Font("SansSerif", Font.PLAIN, 20));

        // Enable minor ticks and grid lines
        domainAxis.setMinorTickMarksVisible(true);
        domainAxis.setMinorTickCount(2); // 2 minor ticks between major ticks (adjust as needed)
        plot.setDomainMinorGridlinesVisible(true);
        plot.setDomainMinorGridlinePaint(java.awt.Color.WHITE);

        // Major grid lines (already visible, but you can set color if needed)
        plot.setDomainGridlinesVisible(true);
        plot.setDomainGridlinePaint(java.awt.Color.WHITE);

        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setLabelFont(new Font("SansSerif", Font.PLAIN, 20));
        rangeAxis.setTickLabelFont(new Font("SansSerif", Font.PLAIN, 20));

        Shape shape = new Ellipse2D.Double(-5, -5, 12, 12);
        for (int i = 0; i < dataset.getSeriesCount(); i++) {
            renderer.setSeriesShape(i, shape);
        }

        return chart;
    }
}
