# Enhanced Plotting of Action Likelihood Values for Two Agents
import matplotlib.pyplot as plt
import numpy as np

# Data for the first agent
actions_0 = np.arange(24)
values_0 = [
    4.831838280000027E-6, 2.264924160000117E-5, 7.549747200000045E-5, 
    3.538944000000186E-4, 0.00117964800000062, 0.0055296000000027,
    0.0184320000000009, 0.0864000000000041, 0.2880000000000137, 
    0.6000000000000263, 2.125064917291354E-14, 9.96124179989329E-14, 
    3.3204139332677044E-13, 1.55644032192526E-12, 5.18814677970844E-12,
    2.431947397880816E-11, 8.1064793266942E-11, 3.799211238573E-10, 
    1.2666373951975944E-9, 5.937362789999343E-9, 2.271199285099645E-8, 
    3.092376453121474E-7, 1.4495514642000079E-6, 1.4495514642000079E-6
]
chosen_action_0 = 9
best_values_0 = values_0[:10]

# Data for the second agent
actions_1 = np.arange(24)
values_1 = [
    0.0377, 0.0449, 0.0517, 0.0616, 0.0709, 0.0845,
    0.0973, 0.1160, 0.1335, 0.1035, 0.0012, 0.0049, 
    0.0056, 0.0067, 0.0077, 0.0092, 0.0106, 0.0126,
    0.0146, 0.0174, 0.0238, 0.0268, 0.0274, 0.0327
]
chosen_action_1 = 8
best_values_1 = values_1[:9]

# Function to create enhanced plot
def plot_agent(actions, values, best_values, chosen_action, title):
    plt.figure(figsize=(10, 8))
    bar_width = 0.8

    # Plot all bars in gray
    bars = plt.bar(actions, values, color='gray', width=bar_width, label="Other Actions")

    # Highlighting best values
    for i in range(len(best_values)):
        for j in range(i + 1):
            plt.bar(j, best_values[j], color='#527cc3', alpha=0.3 + (0.7 * (j + 1) / len(best_values)), label="Best Actions" if i == 0 and j == 0 else "")

    # Highlighting the chosen action
    plt.bar(chosen_action, values[chosen_action], color='red', label="Chosen Action")

    # Adding value labels
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2.0, height, f'{height:.1e}', 
                 ha='center', va='bottom', fontsize=12, rotation=90)

    # Adjust y-axis to fit the highest bar
    max_value = max(values)
    plt.ylim(0, max_value * 1.1)  # Add 10% padding above the highest bar

    # Adjust x-axis to remove white space
    plt.xlim(-0.5, len(actions) - 0.5)  # Tighten the x-axis limits

    # Add title and labels
    plt.title(title, fontsize=17)
    plt.xlabel("Actions", fontsize=17)
    plt.ylabel("Likelihood Values", fontsize=17)
    plt.xticks(np.arange(24), np.arange(24), fontsize=15)

    # Add legend
    plt.legend(fontsize=15)

    plt.tight_layout()
    plt.show()

# Plotting both agents
plot_agent(actions_0, values_0, best_values_0, chosen_action_0, "Agent 0: Action Likelihood Values")
plot_agent(actions_1, values_1, best_values_1, chosen_action_1, "Agent 1: Action Likelihood Values")
