import pandas as pd
import plotly.graph_objects as go

# Load the CSV file
file_path = "C:\\Users\\grace\\Desktop\\Courses\\Master_thesis2\\Thesis code versions\\my-project\\Experiements\\multiplelevels\\ToM2_Level_Analysis.csv"
data = pd.read_csv(file_path)

# Ensure the 'Opponent ToM Level' column is treated as categorical (string)
data['Opponent ToM Level'] = data['Opponent ToM Level'].astype(str)

# Pivot the data to create matrices for the surface plot
solo_payoffs = data.pivot(index='Learning Speed', columns='Opponent ToM Level', values='Solo Agent Payoff')
opponent_payoffs = data.pivot(index='Learning Speed', columns='Opponent ToM Level', values='Opponent Payoff')

# Create the 3D surface plot
fig = go.Figure()

# Add the solo agent's payoff surface
fig.add_trace(go.Surface(
    z=solo_payoffs.values,
    x=solo_payoffs.columns,
    y=solo_payoffs.index,
    colorscale='Viridis',
    colorbar=dict(title="Agent Payoff", len=0.5, x=0.9),  # Separate color bar
    name='Agent Payoff'
))

# Add the opponent's payoff surface
fig.add_trace(go.Surface(
    z=opponent_payoffs.values,
    x=opponent_payoffs.columns,
    y=opponent_payoffs.index,
    colorscale='Cividis',
    colorbar=dict(title="Opponent Payoff", len=0.5, x=1.05),  # Separate color bar
    name='Opponent Payoff',
    opacity=0.8  # Make it slightly transparent for better visibility
))

# Add labels and title
fig.update_layout(
    title="3D Visualization of Payoffs",
    scene=dict(
        xaxis_title="Opponent ToM Level",
        yaxis_title="Agent Learning Speed",
        zaxis_title="Performance"
    )
)

# Show the plot
fig.show()