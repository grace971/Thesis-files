package com.Visualization;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

public class LearningSpeedPayoffVisualization {

    public static void displayLearningSpeedPayoffChart(String filePath) {
        SwingUtilities.invokeLater(() -> {
            // Read data from CSV
            DefaultCategoryDataset dataset = createDatasetFromCSV(filePath);

            // Create the bar chart
            JFreeChart barChart = ChartFactory.createBarChart(
                    "Performance of TOM2 Agent (learning speed= 0.2) and its ToM2 Opponent across all learning speeds over 100 rounds", // Chart title
                    "Opponent Learning Speeds", // X-axis label
                    "Total Payoff", // Y-axis label
                    dataset // Dataset
            );

            // Customize the chart
            CategoryPlot plot = barChart.getCategoryPlot();
            BarRenderer renderer = (BarRenderer) plot.getRenderer();

            // Set colors for the bars
            renderer.setSeriesPaint(0, new Color(79, 129, 189)); // Solo agent's bars
            renderer.setSeriesPaint(1, new Color(192, 80, 77)); // Opponent's bars

            // Display values on top of the bars
            renderer.setDefaultItemLabelGenerator(new StandardCategoryItemLabelGenerator());
            renderer.setDefaultItemLabelsVisible(true);

            // Adjust bar width
            renderer.setMaximumBarWidth(0.1);

            // Customize axes
            CategoryAxis domainAxis = plot.getDomainAxis();
            domainAxis.setCategoryMargin(0.2); // Adjust spacing between groups
            NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
            rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

            // Display the chart in a new window
            JFrame frame = new JFrame("Learning Speed Payoff Chart");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setLayout(new BorderLayout());
            frame.add(new ChartPanel(barChart), BorderLayout.CENTER);
            frame.pack();
            frame.setVisible(true);
        });
    }

    private static DefaultCategoryDataset createDatasetFromCSV(String filePath) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isHeader = true;

            while ((line = br.readLine()) != null) {
                if (isHeader) {
                    isHeader = false; // Skip the header row
                    continue;
                }

                String[] values = line.split(",");
                double opponentLearningSpeed = Double.parseDouble(values[1]);
                double soloPayoff = Double.parseDouble(values[2]);
                double opponentPayoff = Double.parseDouble(values[3]);

                // Add data to the dataset
                dataset.addValue(soloPayoff, "Solo Agent Total Payoff", String.valueOf(opponentLearningSpeed));
                dataset.addValue(opponentPayoff, "Opponent Total Payoff", String.valueOf(opponentLearningSpeed));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return dataset;
    }
}
