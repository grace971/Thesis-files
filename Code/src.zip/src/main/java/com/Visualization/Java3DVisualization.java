package com.Visualization;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javafx.application.Application;
import javafx.scene.AmbientLight;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.PointLight;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;

public class Java3DVisualization extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Load data from the CSV file
        String filePath = "C:\\Users\\grace\\Desktop\\Courses\\Master_thesis2\\Thesis code versions\\my-project\\Experiements\\multiplelevels\\ToM_Level_Analysis.csv";
        Group root = new Group();
        try {
            loadCSVData(filePath, root);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Add lighting
        PointLight light = new PointLight(Color.WHITE);
        light.setTranslateX(0);
        light.setTranslateY(-200);
        light.setTranslateZ(-500);
        root.getChildren().add(light);

        AmbientLight ambientLight = new AmbientLight(Color.WHITE);
        root.getChildren().add(ambientLight);

        // Create a scene with a perspective camera
        Scene scene = new Scene(root, 800, 600, true); // Enable depth buffer
        scene.setFill(Color.LIGHTGRAY); // Set a background color for better visibility
        PerspectiveCamera camera = new PerspectiveCamera(true);
        camera.setTranslateZ(-1000); // Move the camera farther back
        camera.setTranslateY(0);     // Center the camera vertically
        camera.setTranslateX(0);     // Center the camera horizontally
        camera.getTransforms().add(new Rotate(-30, Rotate.X_AXIS)); // Tilt the camera down
        camera.getTransforms().add(new Rotate(30, Rotate.Y_AXIS));  // Rotate the camera slightly
        scene.setCamera(camera);

        // Set up the stage
        primaryStage.setTitle("3D Visualization of Payoffs");
        primaryStage.setScene(scene);
        primaryStage.show();

        System.out.println("Number of objects in the scene: " + root.getChildren().size());
    }

    private void loadCSVData(String filePath, Group root) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            reader.readLine(); // Skip the header
            String line;

            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                double learningSpeed = Double.parseDouble(values[0]);
                int opponentToMLevel = Integer.parseInt(values[1]);
                double soloPayoff = Double.parseDouble(values[2]);
                double opponentPayoff = Double.parseDouble(values[3]);

                System.out.println("Loading data: " + line);
                System.out.println("Adding box at x=" + (opponentToMLevel * 50) + ", y=" + (learningSpeed * 500) + ", z=" + (soloPayoff * 100));

                // Add a box for the solo agent's payoff
                Box soloBox = createBox(opponentToMLevel * 20, learningSpeed * 200, soloPayoff * 50, Color.BLUE);
                root.getChildren().add(soloBox);

                // Add a box for the opponent's payoff
                Box opponentBox = createBox(opponentToMLevel * 20 + 10, learningSpeed * 200, opponentPayoff * 50, Color.RED);
                root.getChildren().add(opponentBox);
            }
        }
    }

    private Box createBox(double x, double y, double z, Color color) {
        Box box = new Box(20, 20, 20); // Increase the width, height, and depth
        box.setTranslateX(x);
        box.setTranslateY(-y); // Invert y-axis for better visualization
        box.setTranslateZ(z);

        PhongMaterial material = new PhongMaterial();
        material.setDiffuseColor(color);
        box.setMaterial(material);

        return box;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
