import matplotlib.pyplot as plt

# Agent names and learning speeds
agents = ['Agent3\nλ=0.8', 'Agent2\nλ=0.1', 'Agent1\nλ=0.9', 'Agent0\nλ=0.2']

# Scores: (ToM2 score, ToM3 score)
tom2_scores = [93, 101, 89, 100]
tom3_scores = [98, 95, 79, 97]

# Plot configuration
y_pos = range(len(agents))
bar_height = 0.35

fig, ax = plt.subplots(figsize=(10, 6))

# Plot ToM2 scores
ax.barh(y=[y + bar_height/2 for y in y_pos], width=tom2_scores, height=bar_height,
        color='#527cc3', edgecolor='black', label='ToM2 agent')

# Plot ToM3 scores
ax.barh(y=[y - bar_height/2 for y in y_pos], width=tom3_scores, height=bar_height,
        color='#f0d437', edgecolor='black', label='ToM3 agent')

# Annotate scores
for i, (t2, t3) in enumerate(zip(tom2_scores, tom3_scores)):
    ax.text(t2 + 1, i + bar_height/2, str(t2), va='center', ha='left', fontsize=17, color='red')
    ax.text(t3 + 1, i - bar_height/2, str(t3), va='center', ha='left', fontsize=17, color='red')

# Y-axis labels and formatting
ax.set_yticks(list(y_pos))
ax.set_yticklabels(agents, fontsize=17)
ax.set_xlabel("Score", fontsize=17, fontweight='bold')
ax.set_title("Comparison of ToM2 and ToM3 Agent Scores", fontsize=17, fontweight='bold')
ax.set_xlim(0, 105)
ax.legend(loc='lower right', fontsize=17)

# Set x-tick font size
ax.tick_params(axis='x', labelsize=17)

plt.tight_layout()
plt.show()
