package com.Visualization;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVVisualizationGenerator {

    public static void main(String[] args) {
        // Hardcoded file paths
        String choicesFilePath = "C:\\Users\\grace\\Desktop\\Courses\\Master_thesis2\\Thesis code versions\\my-project\\Experiements\\ToM2 - Repeating\\0.1.5.8.3\\Tom2choices100.csv";
        String payoffsFilePath = "C:\\Users\\grace\\Desktop\\Courses\\Master_thesis2\\Thesis code versions\\my-project\\Experiements\\ToM2 - Repeating\\0.1.5.8.3\\Tom2payoffs100.csv";
        //String filePath = "C:\\Users\\grace\\Desktop\\ToM2_Analysis.csv";

        List<int[]> choicesList = readChoicesFromCSV(choicesFilePath);
        List<double[]> payoffsHistory = readPayoffsFromCSV(payoffsFilePath);

        Visualization.displayCharts(choicesList, payoffsHistory);
        TotalPayoffVisualization.displayTotalPayoffChartFromCSV(payoffsFilePath);
        //LearningSpeedPayoffVisualization.displayLearningSpeedPayoffChart(filePath);

    }

    public static List<int[]> readChoicesFromCSV(String filePath) {
        List<int[]> choicesList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isHeader = true;
            while ((line = br.readLine()) != null) {
                if (isHeader) {
                    isHeader = false;
                    continue;
                }
                String[] values = line.split(",");
                int[] choices = new int[values.length - 1];
                for (int i = 1; i < values.length; i++) {
                    choices[i - 1] = Integer.parseInt(values[i]);
                }
                choicesList.add(choices);
            }
        } catch (IOException e) {
            System.err.println("Error reading choices CSV file: " + e.getMessage());
        }
        return choicesList;
    }

    public static List<double[]> readPayoffsFromCSV(String filePath) {
        List<double[]> payoffsHistory = new ArrayList<>();
        int[] totalPayoffs = null; // Array to store total payoffs for each agent

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isHeader = true;
            List<List<Double>> tempPayoffs = new ArrayList<>();

            while ((line = br.readLine()) != null) {
                if (isHeader) {
                    isHeader = false;
                    continue;
                }
                String[] values = line.split(",");

                if (totalPayoffs == null) {
                    totalPayoffs = new int[values.length - 1]; // Initialize based on number of agents
                }

                double[] payoffs = new double[values.length - 1];
                for (int i = 1; i < values.length; i++) {
                    payoffs[i - 1] = Double.parseDouble(values[i]);
                    totalPayoffs[i - 1] += (int) payoffs[i - 1]; // Sum up payoffs for each agent
                }

                System.out.println("Total payoffs for each agent:");
                for (int i = 0; i < totalPayoffs.length; i++) {
                    System.out.println("Agent " + i + ": " + totalPayoffs[i]);
                }

                for (int i = 1; i < values.length; i++) { // Skip "Round" column
                    if (tempPayoffs.size() < (i)) {
                        tempPayoffs.add(new ArrayList<>());
                    }
                    try {
                        double parsedValue = Double.parseDouble(values[i]);
                        if (parsedValue != 0.0 && parsedValue != 1.0) { // Debugging step
                            System.err.println("Unexpected payoff value: " + parsedValue);
                        }
                        tempPayoffs.get(i - 1).add(parsedValue);
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid number format at column " + i + ": " + values[i]);
                    }
                }
            }

            // Convert List<List<Double>> to List<double[]>
            for (List<Double> agentPayoffs : tempPayoffs) {
                double[] array = agentPayoffs.stream().mapToDouble(d -> d).toArray();
                payoffsHistory.add(array);
            }

        } catch (IOException e) {
            System.err.println("Error reading payoffs CSV file: " + e.getMessage());
        }

        return payoffsHistory;
    }

}
