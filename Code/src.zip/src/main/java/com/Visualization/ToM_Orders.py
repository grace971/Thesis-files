import matplotlib.pyplot as plt
from matplotlib.patches import Patch

fig, ax = plt.subplots(figsize=(10, 3))

# Ticks and labels
ticks = range(1, 25)
ax.set_xticks(ticks)
ax.set_xticklabels(ticks, fontsize=14)
ax.set_yticks([])
ax.set_ylim(0, 0.5) 


# Draw arrows pointing down directly on ticks 6 and 7 (shorter arrows)
#ax.annotate('', xy=(6, 0), xytext=(6, 0.25),
            #arrowprops=dict(facecolor='limegreen', edgecolor='limegreen', arrowstyle='-|>', mutation_scale=25))
ax.annotate('', xy=(6, 0), xytext=(6, 0.25),
            arrowprops=dict(facecolor='limegreen', edgecolor='limegreen', arrowstyle='-|>', mutation_scale=25))
ax.annotate('', xy=(9, 0), xytext=(9, 0.25),
            arrowprops=dict(facecolor='#0091ea', edgecolor='#0091ea', arrowstyle='-|>', mutation_scale=25))
ax.annotate('', xy=(6, 0), xytext=(7, 0.15),
            arrowprops=dict(facecolor='#FFBF00', edgecolor='#FFBF00', arrowstyle='-|>' , mutation_scale=25))
ax.annotate('', xy=(7, 0), xytext=(7, 0.15),
            arrowprops=dict(facecolor='#FFBF00', edgecolor='#FFBF00', arrowstyle='-|>', mutation_scale=25))
ax.annotate('', xy=(8, 0), xytext=(8, 0.15),
            arrowprops=dict(facecolor='#c97aff', edgecolor='#c97aff', arrowstyle='-|>', mutation_scale=25))

# Label above blue arrow, closer to the arrow
ax.text(9, 0.32, "(+2 higher)", color='#0091ea', ha='center', fontsize=14, fontweight='bold')

# Custom legend, closer to the right and above the scale
legend_elements = [
    Patch(facecolor='limegreen', edgecolor='limegreen', label="Agent's prediction of its opponent choice"),
    Patch(facecolor='#0091ea', edgecolor='#0091ea', label="Agent's possible choices"),
    Patch(facecolor='#FFBF00', edgecolor='#FFBF00', label="Agent's possible choices as a ToM₀ agent"),
    Patch(facecolor='#c97aff', edgecolor='#c97aff', label="Agent's possible choices as a ToM₁ agent")
]
ax.legend(handles=legend_elements, loc='upper left', bbox_to_anchor=(0.5, 0.5), fontsize=14, frameon=False)

# Title, closer to the scale
#ax.set_title("ToM₁ Agent Behavior", fontsize=16, color='black', pad=10, loc='center')
ax.set_title(r"ToM$_2$ Agent Behavior", fontsize=16, color='black', pad=10, loc='center')

# Remove all spines except bottom
ax.spines['top'].set_visible(False)
ax.spines['left'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['bottom'].set_color('black')

ax.tick_params(axis='x', colors='black')

fig.patch.set_facecolor('white')
ax.set_facecolor('white')

plt.tight_layout()
plt.show()
