//package tom;
package com.example.tom;

public class PlayerToM extends Player {

    Player modelSelf;
    PlayerToM[] modelOther;
    double[] typesOther;
    int[] prediction;
    int order;
    double accuracy = 0.0D;
    private double[] beliefs;

    public PlayerToM(int order, Player zeroOrder) {
        this.order = order;
        //setGame(zeroOrder.getGame());
        this.game = zeroOrder.getGame();
        setPlayerID(zeroOrder.getPlayerID());
        if (order == 0) {
            this.modelSelf = zeroOrder;
            this.modelOther = null;
        } else {
            this.modelSelf = new PlayerToM(order - 1, zeroOrder);

            int n = getGame().getNumberOfTypes(1 - getPlayerID());
            this.modelOther = new PlayerToM[n];
            this.typesOther = new double[n];
            this.prediction = new int[n];
            for (int i = 0; i < n; i++) {
                this.typesOther[i] = getGame().getBaseTypeProbability(1 - getPlayerID(), i);
                this.modelOther[i] = new PlayerToM(order - 1, getGame().getPlayerType(1 - getPlayerID(), i));
            }
        }
    }

    @Override
    public double getValue(int state, int action) {
        double value = 0.0D;
        if (this.order > 0) {
            for (int i = 0; i < this.modelOther.length; i++) {
                this.prediction[i] = this.modelOther[i].playRound(state);
                value += this.typesOther[i] * this.game.getPayoff(this, action, this.prediction[i]);
                System.out.println("Other player type " + i + ": prediction = " + this.prediction[i] + ", typesOther = " + this.typesOther[i]);
                System.out.flush();
            }
            double finalValue = (1.0 - this.accuracy) * this.modelSelf.getValue(state, action) + this.accuracy * value;
            System.out.println("Order " + this.order + " final value: " + finalValue);
            return finalValue;
        }
        return this.modelSelf.getValue(state, action);
    }

    @SuppressWarnings("override")
    public void init(Game game, int id) {
        this.accuracy = 0.0D;
        this.modelSelf.init(game, id);
        if (this.order > 0) {
            for (int i = 0; i < this.modelOther.length; i++) {
                this.modelOther[i].init(game, 1 - id);
                this.typesOther[i] = getGame().getBaseTypeProbability(1 - getPlayerID(), i);
            }
        }
    }

    @SuppressWarnings("override")
    public void observe(int playerID, double[] likelihoods) {
        double correctPredictions = 0.0D;
        double sumTypes = 0.0D;
        int i;
        this.modelSelf.observe(playerID, likelihoods);
        if (this.order > 0) {
            if (playerID != getPlayerID()) {
                for (i = 0; i < this.modelOther.length; i++) {
                    this.typesOther[i] = (this.typesOther[i] * (1.0D - getLearningSpeed()) + getLearningSpeed() * likelihoods[this.prediction[i]]);
                    sumTypes += this.typesOther[i];
                    correctPredictions += this.typesOther[i] * likelihoods[this.prediction[i]];
                }
                this.accuracy += getLearningSpeed() * (correctPredictions - this.accuracy);
                if (sumTypes > 0.0D) {
                    sumTypes = 1.0D / sumTypes;
                    for (i = 0; i < this.modelOther.length; i++) {
                        this.typesOther[i] *= sumTypes;
                    }
                } else {
                    for (i = 0; i < this.modelOther.length; i++) {
                        this.typesOther[i] = getGame().getBaseTypeProbability(1 - getPlayerID(), i);
                    }
                }
            }
            for (i = 0; i < this.modelOther.length; i++) {
                this.modelOther[i].observe(playerID, likelihoods);
            }
        }
    }

    @SuppressWarnings("override")
    public void setLearningSpeed(double learningSpeed) {
        this.learningSpeed = learningSpeed;
        this.modelSelf.setLearningSpeed(learningSpeed);
        if (this.order > 0) {
            for (PlayerToM modelOther1 : this.modelOther) {
                modelOther1.setLearningSpeed(learningSpeed);
            }
        }
    }

    @Override
    public void reset() {

        this.learningSpeed = 0.0;  // Reset learning speed if applicable
        //this.beliefs = new double[this.game.getNumberOfActions(this.playerID)];
        if (beliefs != null) {
            for (int i = 0; i < beliefs.length; i++) {
                beliefs[i] = 0.0; // Reset beliefs to their initial state
            }
        }
        System.out.println("PlayerToM (ID " + this.playerID + ") has been reset.");
    }
}
