//package tom;
package com.example.tom;

public abstract interface Game {

    public abstract int getState();

    public abstract int getNumberOfActions(int paramInt);

    public abstract Player getPlayerType(int paramInt1, int paramInt2);

    public abstract int getNumberOfTypes(int paramInt);

    public abstract double getBaseTypeProbability(int paramInt1, int paramInt2);

    public abstract double getPayoff(Player paramPlayer, int paramInt1, int paramInt2);
//  public abstract double getPayoffWithID(int ID, int actionSelf, int actionOther);
}
