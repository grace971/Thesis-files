//package tom;
package com.example.tom;

import java.util.ArrayList;
import java.util.List;

public abstract class Player {

    Game game;
    int playerID;
    double learningSpeed;

    public abstract double getValue(int paramInt1, int paramInt2);

    public void observe(int playerID, int action) {
        double[] likelihoods = new double[this.game.getNumberOfActions(playerID)];
        likelihoods[action] = 1.0D;
        observe(playerID, likelihoods);
    }

    public abstract void observe(int paramInt, double[] paramArrayOfDouble);

    public abstract void init(Game paramGame, int paramInt);

    public abstract void reset(); // Add a reset method

    public int playRound(int state) {
        List<Integer> choice = new ArrayList<>();
        choice.add(0);
        double bestValue = getValue(state, 0);
        System.out.println("Initial bestValue for action 0: " + bestValue);
        System.out.flush();
        int n = this.game.getNumberOfActions(getPlayerID());
        for (int i = 1; i < n; i++) {
            double curValue = getValue(state, i);
            System.out.println("Action " + i + ": curValue = " + curValue);
            System.out.flush();
            if (curValue > bestValue) {
                bestValue = curValue;
                choice.clear();
                choice.add(i);
                System.out.println("New best action " + i + " with bestValue = " + bestValue);
                System.out.flush();
            } else if (curValue == bestValue) {
                choice.add(i);
                System.out.println("Equal best action " + i + " with bestValue = " + bestValue);
                System.out.flush();
            }
        }
        int i = choice.get((int) (choice.size() * Math.random()));
        System.out.println("Chosen action: " + i);
        System.out.flush();
        return i;
    }

    public int playRound() {
        return playRound(0);
    }

    public Game getGame() {
        return this.game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public int getPlayerID() {
        return this.playerID;
    }

    public void setPlayerID(int playerID) {
        this.playerID = playerID;
    }

    public double getLearningSpeed() {
        return this.learningSpeed;
    }

    public void setLearningSpeed(double learningSpeed) {
        this.learningSpeed = learningSpeed;
    }

}
