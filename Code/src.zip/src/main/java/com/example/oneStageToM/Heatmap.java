package com.example.oneStageToM;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Heatmap {

    public static void generateHeatmap(double[][] data, String title) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Check if the data is 1D (single row)
        boolean is1D = data.length == 1;

        // Populate the dataset
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                if (is1D) {
                    // For 1D data, use "Solo ToM Level" as the row label
                    dataset.addValue(data[i][j], "Solo ToM Level", "ToM " + j);
                } else {
                    // For 2D data, use "ToM i" as the row label
                    dataset.addValue(data[i][j], "ToM " + i, "ToM " + j);
                }
            }
        }

        // Create the heatmap chart
        JFreeChart chart = ChartFactory.createBarChart(
                title,
                "Opponent ToM Level",
                is1D ? "Solo ToM Level" : "Player ToM Level",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        // Customize the chart
        NumberAxis rangeAxis = (NumberAxis) chart.getCategoryPlot().getRangeAxis();
        rangeAxis.setRange(0.0, 1.0); // Set range to [0, 1]

        // Display the chart in a JFrame
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new ChartPanel(chart));
        frame.pack();
        frame.setVisible(true);
    }

    public static void generateLineChart(double[] data, String title, String soloToMLabel) {
        // Create a dataset for the line chart
        XYSeries series = new XYSeries(soloToMLabel);

        // Populate the dataset with the performance data
        for (int i = 0; i < data.length; i++) {
            series.add(i, data[i]); // x-axis: Opponent ToM Level, y-axis: Payoff
        }

        XYSeriesCollection dataset = new XYSeriesCollection(series);

        // Create the line chart
        JFreeChart chart = ChartFactory.createXYLineChart(
                title,
                "Opponent ToM Level", // x-axis label
                "Payoff", // y-axis label
                dataset,
                PlotOrientation.VERTICAL,
                true, // Include legend
                true, // Tooltips
                false // URLs
        );

        // Customize the chart
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setSeriesShapesVisible(0, true); // Show data points
        renderer.setSeriesLinesVisible(0, true);  // Show lines

        chart.getXYPlot().setRenderer(renderer);

        NumberAxis rangeAxis = (NumberAxis) chart.getXYPlot().getRangeAxis();
        rangeAxis.setRange(0.0, 1.0); // Set range to [0, 1]

        // Display the chart in a JFrame
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new ChartPanel(chart));
        frame.pack();
        frame.setVisible(true);
    }
}
