package com.example.oneStageToM;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.Visualization.Visualization;
import com.example.tom.Game;
import com.example.tom.Player;
import com.example.tom.PlayerToM;

public class Mod24Tester {

    public static void main(String[] args) {
        java.util.Random random = new java.util.Random();
        random.setSeed(1234);
        // int[] tomLevels = new int[]{0, 1, 2, 2};
        // int[] tomLevels = new int[]{0, 1, 2, 2};
        //int[] tomLevels = new int[]{3, 3};
        int[] tomLevels = new int[]{0, 0, 0};
        //int[] tomLevels = new int[]{2, 2, 2, 2, 2};
        //int[] tomLevels = new int[]{3, 3, 3, 3, 3};
        // Four players: one ToM0, one ToM1, and two ToM2 //, 0.5, 0.8, 0.3
        double[] learningSpeeds = new double[]{0.8, 0.1, 0.5}; //0.1, 0.5, 0.8, 0.9, 0.3 //0.4, 0.4, 0.4, 0.4, 0.4
        int numberOfRounds = 50;
        List<int[]> choicesList = new ArrayList<>();
        List<double[]> payoffsHistory = new ArrayList<>();

        play_mod24_game(numberOfRounds, tomLevels, learningSpeeds, choicesList, payoffsHistory);
        ///* 
        // Save choices to CSV                                                                                                                                                                                                                                            
        String csvData = choicesToCSV(choicesList);
        writeCSVToFile(csvData, "/Users/grace/Desktop/Courses/Master_thesis2/Thesis code versions/my-project/Experiements/3 agents exp/TOM0/50/0.8.1.5/choices0.8.1.5.csv");
        // Save payoffs to CSV
        ///*
        String payoffsCsvData = payoffsToCSV(payoffsHistory);
        writeCSVToFile(payoffsCsvData, "/Users/grace/Desktop/Courses/Master_thesis2/Thesis code versions/my-project/Experiements/3 agents exp/TOM0/50/0.8.1.5/payoffs0.8.1.5.csv");
        //*/
        // Display the charts using the Visualization class
        Visualization.displayCharts(choicesList, payoffsHistory);
    }

    public static void play_mod24_game(int numberOfRounds, int[] tomLevels, double[] learningSpeeds, List<int[]> choicesList, List<double[]> payoffsHistory) {
        int numberOfPlayers = tomLevels.length;
        Game mod24Game = getGame(24);
        Player[] agents = new Player[numberOfPlayers];

        for (int i = 0; i < agents.length; ++i) {
            agents[i] = new PlayerToM(tomLevels[i], new OneStagePlayer(mod24Game, 0));
            agents[i].setLearningSpeed(learningSpeeds[i]);
        }

        // Reset players before the game starts
        for (Player agent : agents) {
            agent.reset();
            System.out.println("Player reset");
        }

        double[] totalPayoffs = new double[numberOfPlayers];
        for (int i = 0; i < numberOfPlayers; i++) {
            payoffsHistory.add(new double[numberOfRounds]);
        }

        for (int round = 0; round < numberOfRounds; ++round) {
            int[] choices = new int[numberOfPlayers];
            double[] choiceDistribution = new double[mod24Game.getNumberOfActions(0)];

            for (int i = 0; i < agents.length; ++i) {
                choices[i] = agents[i].playRound();
                choiceDistribution[choices[i]] += 1.0 / numberOfPlayers;
            }

            choicesList.add(choices.clone());
            System.out.println("Round " + (round + 1) + ":");

            for (int i = 0; i < agents.length; ++i) {
                double payoff = 0.0;
                for (int j = 0; j < agents.length; ++j) {
                    if (i != j && (choices[i] == (choices[j] + 1) % 24)) {
                        payoff += 1.0;
                    }
                }
                totalPayoffs[i] += payoff;
                payoffsHistory.get(i)[round] = payoff;
                System.out.println("Agent " + i + ": Choice = " + choices[i] + ", Payoff = " + payoff + ", Total Payoff = " + totalPayoffs[i]);
            }

            for (int i = 0; i < agents.length; ++i) {
                agents[i].observe(1, choiceDistribution);
                agents[i].observe(0, choiceDistribution);
            }
        }
    }

    public static Game getGame(int n) {
        OneStageGame modNgame = new OneStageGame();
        double[][][] payoffs = new double[2][n][n];
        for (int i = 0; i < n; i++) {
            payoffs[0][((i + 1) % n)][i] = 1.0D;
            payoffs[1][i][((i + 1) % n)] = 1.0D;
        }
        modNgame.setPayoffMatrix(payoffs);
        return modNgame;
    }

    public static String choicesToCSV(List<int[]> choicesList) {
        StringBuilder sb = new StringBuilder();
        int numberOfPlayers = choicesList.get(0).length;

        // Add header
        sb.append("Round");
        for (int i = 0; i < numberOfPlayers; i++) {
            sb.append(",Agent").append(i);
        }
        sb.append("\n");

        // Add data
        for (int round = 0; round < choicesList.size(); round++) {
            sb.append(round);
            for (int choice : choicesList.get(round)) {
                sb.append(",").append(choice);
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public static String payoffsToCSV(List<double[]> payoffsHistory) {
        StringBuilder sb = new StringBuilder();
        int numberOfPlayers = payoffsHistory.size();
        int numberOfRounds = payoffsHistory.get(0).length;

        // Add header
        sb.append("Round");
        for (int i = 0; i < numberOfPlayers; i++) {
            sb.append(",Agent").append(i);
        }
        sb.append("\n");

        // Add data
        for (int round = 0; round < numberOfRounds; round++) {
            sb.append(round);
            for (int playerId = 0; playerId < numberOfPlayers; playerId++) {
                sb.append(",").append(payoffsHistory.get(playerId)[round]);
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public static void writeCSVToFile(String csvData, String filePath) {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(csvData);
        } catch (IOException e) {
            System.err.println("Error writing CSV to file: " + e.getMessage());
        }
    }
}
