package com.example.oneStageToM;

import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.example.tom.Game;
import com.example.tom.Player;
import com.example.tom.PlayerToM;

public class ToMLevelAnalyzer {

    public static void main(String[] args) {
        Game modNgame = getGame(24); // Create the game
        int numberOfRounds = 100; // Number of rounds per game

        // Specify the range of learning speed values for the opponent
        double[] learningSpeeds = {0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0};

        // Analyze the performance of the solo agent for each opponent learning speed
        String csvData = analyzeLearningSpeeds(modNgame, numberOfRounds, learningSpeeds);

        // Save the results to a CSV file
        String filePath = "C:\\Users\\grace\\Desktop\\Courses\\Master_thesis2\\Thesis code versions\\my-project\\Experiements\\multiplelevels\\ToM2_heatmap.csv";
        writeCSVToFile(csvData, filePath);
    }

    public static String analyzeLearningSpeeds(Game game, int numberOfRounds, double[] learningSpeeds) {
        int tomLevel = 2; // Fixed ToM level for both the solo agent and the opponent
        double fixedSoloLearningSpeed = 0.2; // Fixed learning speed for the solo agent
        StringBuilder sb = new StringBuilder();

        // Add header to the CSV file
        sb.append("Solo Learning Speed,Opponent Learning Speed,Solo Agent Total Payoff,Opponent Total Payoff\n");

        for (double opponentLearningSpeed : learningSpeeds) {
            Player soloPlayer = new PlayerToM(tomLevel, new OneStagePlayer(game, 0)); // Solo agent is ToM2
            Player opponentPlayer = new PlayerToM(tomLevel, new OneStagePlayer(game, 1)); // Opponent is also ToM2

            soloPlayer.setLearningSpeed(fixedSoloLearningSpeed); // Set fixed learning speed for the solo player
            opponentPlayer.setLearningSpeed(opponentLearningSpeed); // Set learning speed for the opponent

            // Reset players before the game starts
            soloPlayer.reset();
            opponentPlayer.reset();

            double totalPayoffSolo = 0.0;
            double totalPayoffOpponent = 0.0;

            // Play the game for the specified number of rounds
            for (int round = 0; round < numberOfRounds; round++) {
                int soloChoice = soloPlayer.playRound();
                int opponentChoice = opponentPlayer.playRound();

                // Calculate payoffs using modular arithmetic
                double payoffSolo = 0.0;
                double payoffOpponent = 0.0;

                if (soloChoice == (opponentChoice + 1) % 24) {
                    payoffSolo = 1.0;
                }
                if (opponentChoice == (soloChoice + 1) % 24) {
                    payoffOpponent = 1.0;
                }

                totalPayoffSolo += payoffSolo;
                totalPayoffOpponent += payoffOpponent;

                // Update beliefs using choice distribution
                double[] choiceDistribution = new double[game.getNumberOfActions(0)];
                choiceDistribution[soloChoice] += 1.0 / 2; // Solo agent's choice
                choiceDistribution[opponentChoice] += 1.0 / 2; // Opponent's choice

                soloPlayer.observe(1, choiceDistribution);
                opponentPlayer.observe(0, choiceDistribution);

            }

            // Add the result to the CSV file
            sb.append(fixedSoloLearningSpeed).append(",")
                    .append(opponentLearningSpeed).append(",")
                    .append(totalPayoffSolo).append(",")
                    .append(totalPayoffOpponent).append("\n");
        }

        return sb.toString();
    }

    public static void writeCSVToFile(String csvData, String filePath) {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(csvData);
            System.out.println("CSV file successfully written to: " + filePath);
        } catch (IOException e) {
            Logger.getLogger(ToMLevelAnalyzer.class.getName()).log(Level.SEVERE, "Error writing CSV to file: " + filePath, e);
        }
    }

    public static Game getGame(int n) {
        OneStageGame modNgame = new OneStageGame();
        double[][][] payoffs = new double[2][n][n];
        for (int i = 0; i < n; i++) {
            payoffs[0][((i + 1) % n)][i] = 1.0D;
            payoffs[1][i][((i + 1) % n)] = 1.0D;
        }
        modNgame.setPayoffMatrix(payoffs);
        return modNgame;
    }
}
