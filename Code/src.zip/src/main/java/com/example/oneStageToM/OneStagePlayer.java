//package oneStageToM;
package com.example.oneStageToM;

import com.example.tom.Game;
import com.example.tom.Player;

public class OneStagePlayer
        extends Player {

    int memoryState;
    int memoryDepth = 0;
    double[][] beliefs;

    public OneStagePlayer() {
    }

    public OneStagePlayer(Game game, int id) {
        this(game, id, 0);
    }

    public OneStagePlayer(Game game, int id, int memoryDepth) {
        this.memoryDepth = memoryDepth;
        init(game, id);
    }

    public double getBelief(int action) {
        return this.beliefs[0][action];
    }

    public void setBelief(int action, double value) {
        this.beliefs[0][action] = value;
    }

    public double getValue(int state, int action) {
        double value = 0.0D;
        for (int i = 0; i < this.beliefs[0].length; i++) {
            value += getBelief(i) * ((OneStageGame) getGame()).getPayoff(this, action, i);
        }
        return value;
    }

    public void init(Game game, int id) {
        int i;
        if ((game instanceof OneStageGame)) {
            this.memoryState = 0;
            setPlayerID(id);
            setGame(game);
            int n = game.getNumberOfActions(1 - getPlayerID());
            int m = (int) Math.pow(game.getNumberOfActions(1 - getPlayerID()), this.memoryDepth);
            this.beliefs = new double[m][n];
            for (int j = 0; j < this.beliefs.length; j++) {
                double totalValue = 0.0D;
                for (i = 0; i < n; i++) {
                    this.beliefs[j][i] = Math.random();
                    totalValue += this.beliefs[j][i];
                }
                totalValue = 1.0D / totalValue;
                for (i = 0; i < n; i++) {
                    this.beliefs[j][i] *= totalValue;
                }
            }
        }
    }

    @Override
    public void observe(int playerID, double[] likelihoods) {
        int newState = 0;
        if (playerID == 1 - getPlayerID()) {
            for (int i = 0; i < this.beliefs[0].length; i++) {
                if (likelihoods[i] > likelihoods[newState]) {
                    newState = i;
                }
                setBelief(i, getBelief(i) * (1.0D - getLearningSpeed()) + getLearningSpeed() * likelihoods[i]);
            }
            this.memoryState = ((this.memoryState * this.beliefs[0].length + newState) % this.beliefs.length);
        }
    }

    @Override
    public void reset() {
        this.memoryState = 0;  // Reset memory state to its initial value

        // Re-initialize beliefs as done in init()
        int n = getGame().getNumberOfActions(1 - getPlayerID());  // Number of opponent's actions
        int m = (int) Math.pow(getGame().getNumberOfActions(1 - getPlayerID()), this.memoryDepth);  // Belief matrix size

        this.beliefs = new double[m][n];
        for (int j = 0; j < this.beliefs.length; j++) {
            double totalValue = 0.0D;
            for (int i = 0; i < n; i++) {
                this.beliefs[j][i] = Math.random();  // Randomize beliefs
                totalValue += this.beliefs[j][i];
            }
            totalValue = 1.0D / totalValue;  // Normalize beliefs
            for (int i = 0; i < n; i++) {
                this.beliefs[j][i] *= totalValue;  // Apply normalization
            }
        }

        System.out.println("OneStagePlayer (ID " + getPlayerID() + ") has been reset.");
    }

}
