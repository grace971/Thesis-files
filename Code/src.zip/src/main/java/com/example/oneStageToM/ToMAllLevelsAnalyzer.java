package com.example.oneStageToM;

import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.example.tom.Game;
import com.example.tom.Player;
import com.example.tom.PlayerToM;

public class ToMAllLevelsAnalyzer {

    public static void main(String[] args) {
        Game modNgame = getGame(24); // Create the game
        int numberOfRounds = 50; // Number of rounds per game

        // Specify the range of learning speed values for the solo agent
        double[] learningSpeeds = {0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0};

        // Analyze the performance of the solo agent for each learning speed
        String csvData = analyzeLearningSpeeds(modNgame, numberOfRounds, learningSpeeds);

        // Save the results to a CSV file
        String filePath = "C:\\Users\\grace\\Desktop\\Courses\\Master_thesis2\\Thesis code versions\\my-project\\Experiements\\multiplelevels\\ToM_Level_Analysis.csv";
        writeCSVToFile(csvData, filePath);
    }

    public static String analyzeLearningSpeeds(Game game, int numberOfRounds, double[] learningSpeeds) {
        int numberOfToMLevels = 2; // ToM levels: 0, 1, 2, 3
        StringBuilder sb = new StringBuilder();
        double[][] roundPayoffs = new double[numberOfToMLevels][numberOfRounds]; // Store round-by-round payoffs

        // Add header to the CSV file
        sb.append("Learning Speed,Opponent ToM Level,Solo Agent Payoff,Opponent Payoff\n");

        for (double learningSpeed : learningSpeeds) {
            for (int tomLevel = 0; tomLevel < numberOfToMLevels; tomLevel++) {
                Player soloPlayer = new PlayerToM(0, new OneStagePlayer(game, 0)); // Solo agent is ToM0
                Player opponentPlayer = new PlayerToM(tomLevel, new OneStagePlayer(game, 1));

                soloPlayer.setLearningSpeed(learningSpeed); // Set learning speed for the solo player
                opponentPlayer.setLearningSpeed(0.5); // Fixed learning speed for the opponent

                double totalPayoffSolo = 0.0;
                double totalPayoffOpponent = 0.0;

                // Play the game for the specified number of rounds
                for (int round = 0; round < numberOfRounds; round++) {
                    int soloChoice = soloPlayer.playRound();
                    int opponentChoice = opponentPlayer.playRound();

                    double payoffSolo = game.getPayoff(soloPlayer, soloChoice, opponentChoice);
                    double payoffOpponent = game.getPayoff(opponentPlayer, opponentChoice, soloChoice);

                    totalPayoffSolo += payoffSolo;
                    totalPayoffOpponent += payoffOpponent;

                    // Record the payoff for this round
                    roundPayoffs[tomLevel][round] = payoffSolo;

                    // Print details for the solo agent and opponent
                    System.out.println("Round " + (round + 1) + ":");
                    System.out.println("Solo Agent: ToM Level = " + 0 + ", Learning Speed = " + soloPlayer.getLearningSpeed()
                            + ", Choice = " + soloChoice + ", Payoff = " + payoffSolo);
                    System.out.println("Opponent Agent: ToM Level = " + tomLevel + ", Learning Speed = " + opponentPlayer.getLearningSpeed()
                            + ", Choice = " + opponentChoice + ", Payoff = " + payoffOpponent);
                    // Update beliefs
                    double[] soloLikelihoods = new double[game.getNumberOfActions(1)];
                    double[] opponentLikelihoods = new double[game.getNumberOfActions(0)];
                    soloLikelihoods[opponentChoice] = 1.0;
                    opponentLikelihoods[soloChoice] = 1.0;

                    soloPlayer.observe(1, soloLikelihoods);
                    opponentPlayer.observe(0, opponentLikelihoods);
                }

                // Compute the average payoffs
                double averagePayoffSolo = totalPayoffSolo / numberOfRounds;
                double averagePayoffOpponent = totalPayoffOpponent / numberOfRounds;

                // Add the result to the CSV file
                sb.append(learningSpeed).append(",").append(tomLevel).append(",").append(averagePayoffSolo).append(",").append(averagePayoffOpponent).append("\n");
            }
        }

        return sb.toString();
    }

    public static void writeCSVToFile(String csvData, String filePath) {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(csvData);
            System.out.println("CSV file successfully written to: " + filePath);
        } catch (IOException e) {
            Logger.getLogger(ToMLevelAnalyzer.class.getName()).log(Level.SEVERE, "Error writing CSV to file: " + filePath, e);
        }
    }

    public static Game getGame(int n) {
        OneStageGame modNgame = new OneStageGame();
        double[][][] payoffs = new double[2][n][n];
        for (int i = 0; i < n; i++) {
            payoffs[0][((i + 1) % n)][i] = 1.0D;
            payoffs[1][i][((i + 1) % n)] = 1.0D;
        }
        modNgame.setPayoffMatrix(payoffs);
        return modNgame;
    }
}
