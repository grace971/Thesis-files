//package oneStageToM;
package com.example.oneStageToM;

import com.example.tom.Game;
import com.example.tom.Player;

public class OneStageGame implements Game {

    double[][][] payoffMatrix;

    @SuppressWarnings("override")
    public int getNumberOfActions(int playerID) {
        if (playerID == 0) {
            return this.payoffMatrix[0].length;
        }
        return this.payoffMatrix[0][0].length;
    }

    @SuppressWarnings("override")
    public int getState() {
        return 0;
    }

    @SuppressWarnings("override")
    public double getPayoff(Player player, int actionSelf, int actionOther) {
        if (player.getPlayerID() == 0) {
            return this.payoffMatrix[0][actionSelf][actionOther];
        }
        return this.payoffMatrix[1][actionOther][actionSelf];
    }

    public double[][][] getPayoffMatrix() {
        return this.payoffMatrix;
    }

    public void setPayoffMatrix(double[][][] payoffMatrix) {
        this.payoffMatrix = payoffMatrix;
    }

    @SuppressWarnings("override")
    public int getNumberOfTypes(int playerID) {
        return 1;
    }

    @SuppressWarnings("override")
    public Player getPlayerType(int playerID, int type) {
        OneStagePlayer p = new OneStagePlayer(this, playerID);
        return p;
    }

    @SuppressWarnings("override")
    public double getBaseTypeProbability(int playerID, int type) {
        return 1.0D;
    }
}
